package javaPractice;

public class Q21_NestedIf {
    public static void main(String[] args) {
        /*
          oy kullanma yasi :
          age >= 18  ==> oy kullanmaya uygun
          age >= 70  ==> uc kez oy kullanabilir
          70 > age >=50 ==> iki kez oy kullanabilir
          50 > age >=18 ==> bir kez oy kullanabilir, yazdiriniz
         */
    }
}
