package homework;

public class HW_06 {
    public static void main(String[] args) {

    }
}
